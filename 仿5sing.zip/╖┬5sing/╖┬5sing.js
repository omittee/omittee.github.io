var search=document.querySelector('.search>img');
search.onmouseover=function(){
    this.src="./image/search_dark.png";
}
search.onmouseout=function(){
    this.src="./image/search_light.png";
}

var dock=document.querySelector('#menu');
var wrapMenu=document.querySelector('.wrapMenu')
dock.onmouseover=function(){
    wrapMenu.style.display='block';
}
dock.onmouseout=function(){
    wrapMenu.style.display='none';
}
wrapMenu.onmouseover=function(){
    wrapMenu.style.display='block';
}
wrapMenu.onmouseout=function(){
    wrapMenu.style.display='none';
}

var recommend=document.querySelectorAll('#s2>ul>li');
recommend[0].style.backgroundColor='#00bbb3';
recommend[0].style.color='white';
for(var i=0;i<recommend.length;i++){
    recommend[i].onclick=function(){
        for(var j=0;j<recommend.length;j++){
            recommend[j].style.backgroundColor='';
            recommend[j].style.color='';
        }
        this.style.backgroundColor='#00bbb3';
        this.style.color='white';
    }
}

var shift=document.querySelectorAll('.shift');
shift[0].onmouseover=function(){
    this.children[0].src="./image/shift_green.png";
}
shift[0].onmouseout=function(){
    this.children[0].src="./image/shift.png";
}
shift[1].onmouseover=function(){
    this.children[0].src="./image/shift_green.png";
}
shift[1].onmouseout=function(){
    this.children[0].src="./image/shift.png";
}